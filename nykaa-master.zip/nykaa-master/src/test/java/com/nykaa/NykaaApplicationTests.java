package com.nykaa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NykaaApplicationTests {

	@Test
	void contextLoads() {
	}

}
